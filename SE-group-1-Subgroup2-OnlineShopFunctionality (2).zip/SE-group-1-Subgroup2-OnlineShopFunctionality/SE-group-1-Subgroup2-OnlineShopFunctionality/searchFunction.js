function searchFunction(input,searchSet){
    return "ADD SEARCH ALGORITHM";
}
module.exports = searchFunction;